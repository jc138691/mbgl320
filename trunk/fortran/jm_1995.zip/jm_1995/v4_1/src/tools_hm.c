/* tools_hm.f -- translated by f2c (version 20030306).
   You must link the resulting object file with the libraries:
	-lf2c -lm   (in that order)
*/

#ifdef __cplusplus
extern "C" {
#endif
#include "f2c.h"

/* Table of constant values */

static integer c__9 = 9;
static integer c__1 = 1;
static integer c__5 = 5;
static integer c__19 = 19;
static integer c__3 = 3;
static doublereal c_b14 = .4;
static integer c_n1 = -1;
static real c_b27 = (float)-1.;
static doublereal c_b48 = -1.;
static integer c__0 = 0;

/* =====August,1990=========================================================== */
/*            Analytic Independent-Particle Model for Atoms. */
/*            Alex E. S. at al, Phys.Rev., v.184, 1969, p.1 */

/*            -Z0/r is removed from this potential! */
/*             ----------------------------------- */

/* =====By D.A.Konovalov======================MADE IN AUSTRALIA=============== */
/* Subroutine */ int ipmhf_(doublereal *z__, doublereal *z0, doublereal *v, 
	doublereal *grid, integer *nr, doublereal *expcut)
{
    /* Initialized data */

    static doublereal dn[19] = { 1e-30,.215,.563,.858,.979,.88,.776,.708,.575,
	    .5,.561,.621,.729,.817,.868,.885,.881,.862,1.006 };

    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    integer i_dnnt(doublereal *), s_wsle(cilist *), do_lio(integer *, integer 
	    *, char *, ftnlen), e_wsle();
    /* Subroutine */ int s_stop(char *, ftnlen);
    double pow_dd(doublereal *, doublereal *), exp(doublereal);

    /* Local variables */
    static integer i__;
    static doublereal r__, r1, dd, hh;
    static integer nz;
    static doublereal teta;
    static integer jump;
    static doublereal dexpr;

    /* Fortran I/O blocks */
    static cilist io___3 = { 0, 6, 0, 0, 0 };
    static cilist io___4 = { 0, 6, 0, 0, 0 };



/* INPUT: */
/* ----- */
/*  Z     - charge of the atom */
/*  grid  - r-grid, nr - number of points in this grid */
/*  expcut- the smollest value of exp-functions in "IPMDHF.F" */
/*  Z0    - Coulomb potential removed from the potential V. */
/*          V(r) = Vatom(r)  -  Z0 / r     mult-ed by r if  Z.NE.Z0 */

/* OUTPUT: */
/* ------ */
/*  V - Array of the values of the potential multiplyed by r  if  Z.NE.Z0 */

    /* Parameter adjustments */
    --grid;
    --v;

    /* Function Body */
    nz = i_dnnt(z__);

/*     Do same check */

    if (nz < 1 || nz > 19) {
	s_wsle(&io___3);
	do_lio(&c__9, &c__1, "This Z is not available yet,  Z=", (ftnlen)32);
	do_lio(&c__5, &c__1, (char *)&(*z__), (ftnlen)sizeof(doublereal));
	e_wsle();
	s_wsle(&io___4);
	do_lio(&c__9, &c__1, " Max Z=", (ftnlen)7);
	do_lio(&c__3, &c__1, (char *)&c__19, (ftnlen)sizeof(integer));
	e_wsle();
	s_stop("Stop in \"ipmdhf.f\"", (ftnlen)18);
    }

/*     Some constants */

    dd = dn[nz - 1];
    d__1 = *z__ - 1.;
    hh = dd * pow_dd(&d__1, &c_b14);

/*     Loop by r-grid */

    jump = 0;
    i__1 = *nr;
    for (i__ = 1; i__ <= i__1; ++i__) {
	r__ = grid[i__];
	r1 = 1. / r__;
	v[i__] = *z0 - 1.;
	if (jump == 0) {
	    dexpr = exp(-r__ / dd);
	    if (dexpr < *expcut) {
		jump = i__;
	    } else {
		teta = dexpr / (hh * (1. - dexpr) + dexpr);
		v[i__] = -((*z__ - 1.) * teta + 1.) + *z0;
	    }
	}
    }

/*     Put back 1/r if Z.EQ.Z0 */

    if (i_dnnt(z__) == i_dnnt(z0)) {
	i__1 = *nr;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    v[i__] /= grid[i__];
	}
    }
    return 0;
} /* ipmhf_ */

/* ------------------------------------------------------------------------- */

/*     Define such matrix element is possible */

integer irrss_(integer *qnl, integer *nnl, integer *lnl, integer *j1, integer 
	*j2, integer *nsh, integer *ii)
{
    /* System generated locals */
    integer ret_val, i__1, i__2;

    /* Local variables */
    static integer i__, l1, l2, n1, n2, ib, ib2;
    extern integer idl_(integer *, integer *), idnl_(integer *, integer *, 
	    integer *, integer *);
    static integer itmp1, itmp2;



/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */

    /* Parameter adjustments */
    --ii;
    lnl -= 702;
    nnl -= 702;
    qnl -= 702;

    /* Function Body */
    ret_val = 0;

    i__1 = *nsh;
    for (ib = 1; ib <= i__1; ++ib) {
	itmp1 = qnl[*j1 + ib * 701] - idl_(&ib, &ii[1]) - idl_(&ib, &ii[2]);
	itmp2 = qnl[*j2 + ib * 701] - idl_(&ib, &ii[3]) - idl_(&ib, &ii[4]);

/*     Check if there are enough electrons for \sigma's and \rho's */
	if (itmp1 < 0 || itmp2 < 0) {
	    return ret_val;
	}

/*     Check if two configurations have the same spectator electrons, p.A69_Fano */

	if (ib == 1 && itmp1 != itmp2) {
	    return ret_val;
	}

	if (itmp1 > 0 && ib > 1) {
	    n1 = nnl[*j1 + ib * 701];
	    l1 = lnl[*j1 + ib * 701];
	    i__ = 0;
	    i__2 = *nsh;
	    for (ib2 = 2; ib2 <= i__2; ++ib2) {
		n2 = nnl[*j2 + ib2 * 701];
		l2 = lnl[*j2 + ib2 * 701];
		itmp2 = qnl[*j2 + ib2 * 701] - idl_(&ib2, &ii[3]) - idl_(&ib2,
			 &ii[4]);
		if (idnl_(&n1, &l1, &n2, &l2) == 1 && itmp1 == itmp2) {
		    i__ = 1;
		}
	    }
	    if (i__ == 0) {
		return ret_val;
	    }
	}
    }

    ret_val = 1;

    return ret_val;
} /* irrss_ */

/* ------------------------------------------------------------------------- */

/*     Copy shells */

/* Subroutine */ int copysh_(integer *qnl, integer *nnl, integer *lnl, 
	integer *llnl, integer *lsnl, integer *j1, integer *j2, integer *i1, 
	integer *i2, integer *k1, integer *k2)
{


/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */

    /* Parameter adjustments */
    lsnl -= 2805;
    llnl -= 2805;
    lnl -= 2805;
    nnl -= 2805;
    qnl -= 2805;

    /* Function Body */
    qnl[*j2 + (*i2 + *k2 * 3) * 701] = qnl[*j1 + (*i1 + *k1 * 3) * 701];
    nnl[*j2 + (*i2 + *k2 * 3) * 701] = nnl[*j1 + (*i1 + *k1 * 3) * 701];
    lnl[*j2 + (*i2 + *k2 * 3) * 701] = lnl[*j1 + (*i1 + *k1 * 3) * 701];
    llnl[*j2 + (*i2 + *k2 * 3) * 701] = llnl[*j1 + (*i1 + *k1 * 3) * 701];
    lsnl[*j2 + (*i2 + *k2 * 3) * 701] = lsnl[*j1 + (*i1 + *k1 * 3) * 701];

    return 0;
} /* copysh_ */



/*     Create empty shell */

/* Subroutine */ int emptysh_(integer *qnl, integer *nnl, integer *lnl, 
	integer *llnl, integer *lsnl, integer *j, integer *i__, integer *k)
{


/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */
    /* Parameter adjustments */
    lsnl -= 2805;
    llnl -= 2805;
    lnl -= 2805;
    nnl -= 2805;
    qnl -= 2805;

    /* Function Body */
    qnl[*j + (*i__ + *k * 3) * 701] = 0;
    nnl[*j + (*i__ + *k * 3) * 701] = 0;
    lnl[*j + (*i__ + *k * 3) * 701] = 0;
    llnl[*j + (*i__ + *k * 3) * 701] = 0;
    lsnl[*j + (*i__ + *k * 3) * 701] = 1;
    return 0;
} /* emptysh_ */


/*     Check if j's configuration exists already */

/*     newcon = 1, if this configuration is new */
integer newcon_(integer *qnl, integer *nnl, integer *lnl, integer *llnl, 
	integer *lsnl, integer *ll12, integer *ls12, integer *j, integer *k, 
	integer *nsh)
{
    /* System generated locals */
    integer ret_val, i__1, i__2;

    /* Local variables */
    static integer i__, m, ii;



/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */
    /* Parameter adjustments */
    ls12 -= 702;
    ll12 -= 702;
    lsnl -= 2805;
    llnl -= 2805;
    lnl -= 2805;
    nnl -= 2805;
    qnl -= 2805;

    /* Function Body */
    ret_val = 1;

    i__1 = *j - 1;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (ll12[i__ + *k * 701] == ll12[*j + *k * 701] && ls12[i__ + *k * 
		701] == ls12[*j + *k * 701]) {

/*     Check all shells */
	    ii = 0;
	    i__2 = *nsh;
	    for (m = 1; m <= i__2; ++m) {
		if (qnl[i__ + (m + *k * 3) * 701] == qnl[*j + (m + *k * 3) * 
			701] && nnl[i__ + (m + *k * 3) * 701] == nnl[*j + (m 
			+ *k * 3) * 701] && lnl[i__ + (m + *k * 3) * 701] == 
			lnl[*j + (m + *k * 3) * 701] && llnl[i__ + (m + *k * 
			3) * 701] == llnl[*j + (m + *k * 3) * 701] && lsnl[
			i__ + (m + *k * 3) * 701] == lsnl[*j + (m + *k * 3) * 
			701]) {
		    ++ii;
		}
	    }

/*     all nsh-shells are the same */
	    if (ii == *nsh) {
		ret_val = 0;
		return ret_val;
	    }

	}
    }
    return ret_val;
} /* newcon_ */


/*     Triangle rule */

integer itri_(integer *i1, integer *i2, integer *i3)
{
    /* System generated locals */
    integer ret_val, i__1, i__2, i__3;

    ret_val = 1;
    if ((i__1 = *i1 - *i2, abs(i__1)) > *i3 || *i1 + *i2 < *i3 || (i__2 = *i1 
	    - *i3, abs(i__2)) > *i2 || *i1 + *i3 < *i2 || (i__3 = *i2 - *i3, 
	    abs(i__3)) > *i1 || *i2 + *i3 < *i1) {
	ret_val = 0;
    }
    return ret_val;
} /* itri_ */

/* --------------------------------------------------------------------- */

/*     Memory position for a symmetric array */

integer msym_(integer *i1, integer *i2, integer *n)
{
    /* System generated locals */
    integer ret_val;

    /* Local variables */
    static integer i__, j;

    i__ = max(*i1,*i2);
    j = min(*i1,*i2);
    ret_val = ((*n << 1) + 2 - j) * (j - 1) / 2 + (i__ - j + 1);
    return ret_val;
} /* msym_ */

/* --------------------------------------------------------------------- */

/*     Generate arrays for r (rn) and sqrt(r) (r5) with */
/*     a constant mesh size in the log(z*r) variable */

/* Subroutine */ int rn_hm__(doublereal *z__, integer *nr, doublereal *rmin, 
	doublereal *rmax, integer *iy, doublereal *rn, doublereal *r5, 
	doublereal *wn, doublereal *h__)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    double log(doublereal), exp(doublereal), sqrt(doublereal);
    /* Subroutine */ int s_stop(char *, ftnlen);

    /* Local variables */
    static doublereal a[4];
    static integer i__;
    static doublereal rho, tmp;

/*     In */
/*     Out */
/*     IY = 1, Weights are Simpson's otherwise they are Bode's */


/*  *****  set the starting point and the step size */

    /* Parameter adjustments */
    --wn;
    --r5;
    --rn;

    /* Function Body */
    rho = log(*z__ * *rmin);
    *h__ = (log(*z__ * *rmax) - rho) / (doublereal) (*nr - 1);
    i__1 = *nr;
    for (i__ = 1; i__ <= i__1; ++i__) {
	rn[i__] = exp(rho) / *z__;
	r5[i__] = sqrt(rn[i__]);
	rho += *h__;
    }
    rho -= (doublereal) (*nr) * *h__;

    if (*iy == 1) {
/*     Simpson's weights */
	if (*nr % 2 == 0) {
	    s_stop(" nr must be odd, stoped in rn_hm", (ftnlen)32);
	}
	tmp = *h__ * 2. / 3.;
	i__1 = *nr;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    wn[i__] = (doublereal) ((i__ + 1) % 2 + 1) * tmp * rn[i__];
	}
	wn[1] /= 2.;
	wn[*nr] /= 2.;
    } else {
/*     Bode's weights */
	tmp = *h__ * 2. / 45.;
	a[1] = tmp * 14.;
	a[2] = tmp * 32.;
	a[3] = tmp * 12.;
	a[0] = tmp * 32.;
	i__1 = *nr;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    wn[i__] = a[i__ % 4] * rn[i__];
	}
	wn[1] /= 2.;
	wn[*nr] /= 2.;
    }
    return 0;
} /* rn_hm__ */

/*     ------------------------------------------------------------------ */

/*     Stores Y^k (p1, p2; r) in the array Y(r) */

/* Subroutine */ int yk_hm__(integer *i1, integer *i2, doublereal *p1, 
	doublereal *p2, integer *l1, integer *l2, integer *k, integer *nr, 
	doublereal *rn, doublereal *h__, doublereal *zatom, doublereal *y)
{
    /* System generated locals */
    integer i__1;
    doublereal d__1;

    /* Builtin functions */
    double exp(doublereal), pow_di(doublereal *, integer *);

    /* Local variables */
    static doublereal a, c__;
    static integer m;
    static doublereal a2, a3, c1, c2, f1, f2, f3, h3;
    static integer m1, m2;
    static doublereal f4, f5, a34, ai, eh, an, h90;
    static integer mm;
    static doublereal den, fact;

/*     In */
/*     Out */

    /* Parameter adjustments */
    --y;
    --rn;
    --p2;
    --p1;

    /* Function Body */
    eh = exp(-(*h__));
    h3 = *h__ / 3.;

/*     Calculates and stores Z^k (p1, p2; r) in the array Y(r) */

    den = (doublereal) (*l1 + *l2 + 3 + *k);
    fact = (1. / (doublereal) (*l1 + 1) + 1. / (doublereal) (*l2 + 1)) / (den 
	    + 1.);
    a = pow_di(&eh, k);
    a2 = a * a;
    h90 = *h__ / 90.;
    a3 = a2 * a * h90;
    ai = h90 / a;
    an = a * 114. * h90;
    a34 = h90 * 34.;
/* Computing 2nd power */
    d__1 = rn[1];
    f1 = d__1 * d__1 * p1[1] * p2[1];
/* Computing 2nd power */
    d__1 = rn[2];
    f2 = d__1 * d__1 * p1[2] * p2[2];
/* Computing 2nd power */
    d__1 = rn[3];
    f3 = d__1 * d__1 * p1[3] * p2[3];
/* Computing 2nd power */
    d__1 = rn[4];
    f4 = d__1 * d__1 * p1[4] * p2[4];
    y[1] = f1 * (*zatom * rn[1] * fact + 1.) / den;
    y[2] = f2 * (*zatom * rn[2] * fact + 1.) / den;
    y[3] = y[1] * a2 + h3 * (f3 + a * 4. * f2 + a2 * f1);
    i__1 = *nr;
    for (m = 5; m <= i__1; ++m) {
/* Computing 2nd power */
	d__1 = rn[m];
	f5 = d__1 * d__1 * p1[m] * p2[m];
	y[m - 1] = y[m - 3] * a2 + (an * f3 + a34 * (f4 + a2 * f2) - f5 * ai 
		- f1 * a3);
	f1 = f2;
	f2 = f3;
	f3 = f4;
	f4 = f5;
    }
    y[*nr] = a * y[*nr - 1];
    if (*i1 == *i2 && abs(*k) == 0) {

/*  *****  FOR Y0(I,I) SET THE LIMIT TO 1 AND REMOVE OSCILLATIONS */
/*  *****  INTRODUCED BY THE USE OF SIMPSON'S RULE */

	m2 = (*nr / 2 << 1) - 1;
	m1 = m2 - 1;
	c1 = 1. - y[m1];
	c2 = 1. - y[m2];
	i__1 = m1;
	for (m = 1; m <= i__1; m += 2) {
	    y[m] += c1;
	    y[m + 1] += c2;
	}
	y[*nr] = 1.;
	y[*nr - 1] = 1.;
    }

/*     calculate Y^k (p1, p2; r) */

    i__1 = *k + 1;
    a = pow_di(&eh, &i__1);
    c__ = (doublereal) ((*k << 1) + 1);
    a2 = a * a;
    h90 = c__ * h3 / 30.;
    a3 = a2 * a * h90;
    ai = h90 / a;
    an = a * 114. * h90;
    a34 = h90 * 34.;
    f1 = y[*nr] * pow_di(&eh, k);
    f2 = y[*nr];
    f3 = y[*nr - 1];
    f4 = y[*nr - 2];
    i__1 = *nr - 2;
    for (mm = 2; mm <= i__1; ++mm) {
	m = *nr - mm;
	f5 = y[m - 1];
	y[m] = y[m + 2] * a2 + (an * f3 + a34 * (f4 + a2 * f2) - f5 * ai - f1 
		* a3);
	f1 = f2;
	f2 = f3;
	f3 = f4;
	f4 = f5;
    }
/* 	NOTE: Warning: Variable D4 is used before its value has been defined???????!!!!! */
/* $$$      y(1) = y(3) * A2 + C * H3 * (F4 + D4 * A * F3 + A2 * F2) */
    y[1] = y[3] * a2 + c__ * h3 * (f4 + a * (float)0. * f3 + a2 * f2);
    return 0;
} /* yk_hm__ */

/* -------------------------------------------------------------------- */

/*     Scalar product, */
doublereal sc_k__(integer *l1, integer *l2, integer *j1, integer *j2, integer 
	*k, integer *l, doublereal *clkl, doublereal *eps)
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2, r__3, r__4, r__5, r__6;
    doublereal ret_val;

    /* Builtin functions */
    integer pow_ii(integer *, integer *);

    /* Local variables */
    extern doublereal rwig6j_(real *, real *, real *, real *, real *, real *);



/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */
/*      call iot6 (L, l2, l1, k, j1, j2, sc_k) */
    r__1 = (real) (*l);
    r__2 = (real) (*l2);
    r__3 = (real) (*l1);
    r__4 = (real) (*k);
    r__5 = (real) (*j1);
    r__6 = (real) (*j2);
    ret_val = rwig6j_(&r__1, &r__2, &r__3, &r__4, &r__5, &r__6);

    if (abs(ret_val) < *eps) {
	return ret_val;
    }
    i__1 = *j1 + *l2 + *l;
    ret_val = (doublereal) pow_ii(&c_n1, &i__1) * ret_val * clkl[*l1 + (*k + *
	    j1)] * clkl[*l2 + (*k + *j2)];
    return ret_val;
} /* sc_k__ */

/* ---------------------------------------------------------------------- */
/*     itype = */
/*     0  -  (l1 l2) L12, l3 L | (l1, l2) L23, l3 L */
/*     1  -  (l1 l2) L12, l3 L | l1 (l2, l3) L23, L */
/*     10 -  (l1 l2) L12, l3 L | l1 (l3, l2) L23, L */
/*     2  -  (l1 l2) L12, l3 L | (l1, l3) L23, l2 L */
/*     20 -  (l1 l2) L12, l3 L | (l3, l1) L23, l2 L */
/*     3  -  (l1 l2) L12, l3 L | (l3, l2) L23, l1 L */
/*     30 -  (l1 l2) L12, l3 L | (l2, l3) L23, l1 L */
/*     4  -  (l1 l2) L12, l3 L | l1 (l3, l2) L23, L */
/*     5  -  (l1 l2) L12, l3 L | l3 (l2, l1) L23, L */
/*     50 -  (l1 l2) L12, l3 L | l3 (l1, l2) L23, L */
/*     6  -  l1 (l2 l3) L12, L | l3 (l2, l1) L23, L */
/*     60 -  l1 (l2 l3) L12, L | l3 (l1, l2) L23, L */
/*     61 -  l1 (l2 l3) L12, L | l1 (l3, l2) L23, L */
/*     62 -  l1 (l2 l3) L12, L | l2 (l3, l1) L23, L */
/*     620-  l1 (l2 l3) L12, L | l2 (l1, l3) L23, L */
/*     7  -  (l1 l2) L12, l3 L | l2 (l3, l1) L23, L */
/*     70 -  (l1 l2) L12, l3 L | l2 (l1, l3) L23, L */
/*     8  -  (l1 l2) L12, l3 L | (l2, l1) L23, l3 L */

/*     Recoupling */
doublereal u_6j__(integer *itype, integer *l12, integer *l23, integer *l1, 
	integer *l2, integer *l3, integer *l, doublereal *eps, integer *iy)
{
    /* System generated locals */
    integer i__1;
    real r__1, r__2, r__3, r__4, r__5, r__6;
    doublereal ret_val;

    /* Builtin functions */
    double pow_ri(real *, integer *);
    /* Subroutine */ int s_stop(char *, ftnlen);
    integer pow_ii(integer *, integer *);
    double sqrt(doublereal);
    integer i_nint(real *);

    /* Local variables */
    static real f, f1, f2, f3;
    static integer j1, j2, j3;
    static real f12, f23;
    extern doublereal ddl_(integer *, integer *);
    static real phase;
    extern doublereal rwig6j_(real *, real *, real *, real *, real *, real *),
	     rjahnu_(real *, real *, real *, real *, real *, real *);

    ret_val = 0.;
    if (*itype == 0) {
	ret_val = ddl_(l12, l23);
	return ret_val;
    }
    if (*iy == 1) {

	if (*itype == 1) {
	    j1 = *l1;
	    j2 = *l2;
	    j3 = *l3;
	    phase = (float)1.;
	} else if (*itype == 2) {
	    j1 = *l2;
	    j2 = *l1;
	    j3 = *l3;
	    i__1 = *l1 + *l2 - *l12 + *l2 + *l23 - *l;
	    phase = pow_ri(&c_b27, &i__1);
	} else {
	    s_stop(" not ready, U_6j for l1,l2,l3", (ftnlen)29);
	}
	r__1 = (real) j1;
	r__2 = (real) j2;
	r__3 = (real) (*l12);
	r__4 = (real) j3;
	r__5 = (real) (*l);
	r__6 = (real) (*l23);
	ret_val = rwig6j_(&r__1, &r__2, &r__3, &r__4, &r__5, &r__6);
/*         call iot6 (j1, j2, L12, j3, L, L23, U_6j) */

	if (abs(ret_val) < *eps) {
	    return ret_val;
	}
	i__1 = j1 + j2 + j3 + *l;
	ret_val = ret_val * (doublereal) pow_ii(&c_n1, &i__1) * sqrt((
		doublereal) (((*l12 << 1) + 1) * ((*l23 << 1) + 1))) * phase;
    } else {
	f1 = (real) (*l1 - 1) / (float)2.;
	f2 = (real) (*l2 - 1) / (float)2.;
	f3 = (real) (*l3 - 1) / (float)2.;
	f12 = (real) (*l12 - 1) / (float)2.;
	f23 = (real) (*l23 - 1) / (float)2.;
	f = (real) (*l - 1) / (float)2.;
	ret_val = rjahnu_(&f1, &f2, &f, &f3, &f12, &f23);

	if (*itype == 1) {
	    return ret_val;
	} else if (*itype == 10) {
	    r__1 = (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 2) {
	    r__1 = (float)1. - f12 + (float).5 + f23 - f;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 20) {
	    r__1 = (float)1. - f12 + (float).5 + f23 - f + (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 3) {
	    r__1 = f23 + (float).5 - f + (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 30) {
	    r__1 = f23 + (float).5 - f;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 4) {
	    r__1 = (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 5) {
	    r__1 = (float)1. - f23 + (float).5 + f23 - f;
	    i__1 = i_nint(&r__1);
	    ret_val = ddl_(l12, l23) * pow_ri(&c_b27, &i__1);
	} else if (*itype == 50) {
	    r__1 = f23 + (float).5 - f;
	    i__1 = i_nint(&r__1);
	    ret_val = ddl_(l12, l23) * pow_ri(&c_b27, &i__1);
	} else if (*itype == 6) {
	    r__1 = f12 + (float).5 - f + (float)1. - f12;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 60) {
	    r__1 = f12 + (float).5 - f + (float)1. - f12 + (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 61) {
	    r__1 = (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val = ddl_(l12, l23) * pow_ri(&c_b27, &i__1);
	} else if (*itype == 62) {
	    r__1 = f12 + (float).5 - f;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 620) {
	    r__1 = f12 + (float).5 - f + (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 7) {
	    r__1 = (float)1. - f12 + (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 70) {
	    r__1 = (float)1. - f12;
	    i__1 = i_nint(&r__1);
	    ret_val *= pow_ri(&c_b27, &i__1);
	} else if (*itype == 8) {
	    r__1 = (float)1. - f23;
	    i__1 = i_nint(&r__1);
	    ret_val = ddl_(l12, l23) * pow_ri(&c_b27, &i__1);
	} else {
	    s_stop(" not ready, in U_6j", (ftnlen)19);
	}
    }
    return ret_val;
} /* u_6j__ */



doublereal c1_hm__(integer *ii, integer *j1, integer *j2, integer *qnl, 
	doublereal *dir, doublereal *exc, integer *idp, doublereal *eps, 
	integer *n, integer *l)
{
    /* System generated locals */
    doublereal ret_val;

    /* Builtin functions */
    double sqrt(doublereal), pow_di(doublereal *, integer *);

    /* Local variables */
    static integer i1, i2, i3, i4, itmp1, itmp2;



/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */
    /* Parameter adjustments */
    --l;
    --n;
    qnl -= 702;
    --ii;

    /* Function Body */
    i1 = ii[1];
    i2 = ii[2];
    i3 = ii[3];
    i4 = ii[4];
    itmp1 = 0;
    if (n[1] == n[2] && l[1] == l[2]) {
	itmp1 = 1;
    }
    itmp2 = 0;
    if (n[3] == n[4] && l[3] == l[4]) {
	itmp2 = 1;
    }

    if (abs(*dir) + abs(*exc) > *eps) {
	ret_val = pow_di(&c_b48, idp) * .5 * sqrt((doublereal) (qnl[*j1 + i1 *
		 701] * (qnl[*j1 + i2 * 701] - itmp1) * qnl[*j2 + i3 * 701] * 
		(qnl[*j2 + i4 * 701] - itmp2))) * ((doublereal) ((1 - itmp1) *
		 (1 - itmp2) + 1) * *dir - (doublereal) (2 - itmp1 - itmp2) * 
		*exc);
    } else {
	ret_val = 0.;
    }
    return ret_val;
} /* c1_hm__ */



doublereal c2_hm__(integer *l, integer *n, doublereal *h1, doublereal *h2, 
	integer *iy, integer *nel)
{
    /* System generated locals */
    doublereal ret_val;

    /* Local variables */
    extern doublereal ddl_(integer *, integer *);


/* r    nel - total number of electrons in the system */
/* r    IY - switch for direct (IY=1) */


    /* Parameter adjustments */
    --n;
    --l;

    /* Function Body */
    if (*iy == 1) {
	ret_val = ddl_(&l[1], &l[3]) * ddl_(&l[2], &l[4]) / (doublereal) (*
		nel - 1) * (ddl_(&n[1], &n[3]) * *h1 + ddl_(&n[2], &n[4]) * *
		h2);
    } else {
	ret_val = ddl_(&l[1], &l[4]) * ddl_(&l[2], &l[3]) / (doublereal) (*
		nel - 1) * (ddl_(&n[1], &n[4]) * *h1 + ddl_(&n[2], &n[3]) * *
		h2);
    }
    return ret_val;
} /* c2_hm__ */

/* ------------------------------------------------------------------------- */

/*     Define i1 = \rho  and  i2 = \sigma */

/* Subroutine */ int r_s_hm__(integer *qnl, integer *j1, integer *nsh, 
	integer *ib, integer *ii)
{
    /* System generated locals */
    integer i__1;

    /* Local variables */
    static integer ib2;
    extern integer idl_(integer *, integer *);
    static integer irho, itmpv[64], isigma;

/*     IN: */
/*     OUT: */


/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */

    /* Parameter adjustments */
    --ii;
    qnl -= 702;

    /* Function Body */
    irho = 0;
    isigma = 0;
    i__1 = *nsh;
    for (ib2 = 1; ib2 <= i__1; ++ib2) {
	itmpv[ib2 - 1] = qnl[*j1 + ib2 * 701] - idl_(ib, &ib2);
	if (itmpv[ib2 - 1] > 0 && irho == 0) {
	    ii[1] = ib2;
	    --itmpv[ib2 - 1];
	    irho = 1;
	}
    }
    i__1 = *nsh;
    for (ib2 = 1; ib2 <= i__1; ++ib2) {
	if (itmpv[ib2 - 1] > 0 && isigma == 0) {
	    ii[2] = ib2;
	    isigma = 1;
	}
    }
    return 0;
} /* r_s_hm__ */

/* -------------------------------------------------------------------------- */

/*     nel - number of electrons in the configuration */

/* Subroutine */ int d_e_hm_v4_1__(integer *ll, doublereal *hl0, integer *n, 
	integer *l4, integer *ip, integer *ipp, doublereal *pp, doublereal *
	eps, doublereal *clkl, integer *nwf, integer *nr, integer *nel, 
	doublereal *rn, doublereal *wn, doublereal *h__, doublereal *zatom, 
	real *dir, real *exc)
{
    /* System generated locals */
    integer i__1, i__2, i__3, i__4, i__5, i__6, i__7, i__8, i__9;

    /* Builtin functions */
    double pow_ri(real *, integer *);

    /* Local variables */
    static integer i1, i2, kk;
    static doublereal yk2[701], tmp1, tmp2;
    extern doublereal sc_k__(integer *, integer *, integer *, integer *, 
	    integer *, integer *, doublereal *, doublereal *), c2_hm__(
	    integer *, integer *, doublereal *, doublereal *, integer *, 
	    integer *);
    extern /* Subroutine */ int int3_8__(doublereal *, integer *, integer *, 
	    doublereal *, integer *, integer *, doublereal *, integer *, 
	    integer *, doublereal *, doublereal *, integer *), yk_hm__(
	    integer *, integer *, doublereal *, doublereal *, integer *, 
	    integer *, integer *, integer *, doublereal *, doublereal *, 
	    doublereal *, doublereal *);

/*     IN: */
/*     OUT: */


/*     These parameters must be adjusted individually */


/* $$$      parameter (nyk2_par = (nwf_par * (nwf_par + 1)) / 2 ) */
/*     IN: */
/*     OUT: */

/*     direct */
    /* Parameter adjustments */
    --wn;
    --rn;
    pp -= 702;
    ipp -= 65;
    --ip;
    --l4;
    --n;
    hl0 -= 65;

    /* Function Body */
    *dir = (float)0.;
/* Computing MAX */
    i__5 = (i__1 = l4[1] - l4[3], abs(i__1)), i__6 = (i__2 = l4[2] - l4[4], 
	    abs(i__2));
/* Computing MIN */
    i__8 = (i__3 = l4[1] + l4[3], abs(i__3)), i__9 = (i__4 = l4[2] + l4[4], 
	    abs(i__4)), i__8 = min(i__8,i__9);
    i__7 = min(i__8,0);
    for (kk = max(i__5,i__6); kk <= i__7; kk += 2) {
	tmp1 = sc_k__(&l4[1], &l4[2], &l4[3], &l4[4], &kk, ll, clkl, eps);
	if (abs(tmp1) > *eps) {
	    i1 = ip[2];
	    i2 = ip[4];
	    yk_hm__(&i1, &i2, &pp[i1 * 701 + 1], &pp[i2 * 701 + 1], &l4[2], &
		    l4[4], &kk, nr, &rn[1], h__, zatom, yk2);
	    int3_8__(&pp[ip[1] * 701 + 1], &ipp[ip[1] + 64], &ipp[ip[1] + 128]
		    , &pp[ip[3] * 701 + 1], &ipp[ip[3] + 64], &ipp[ip[3] + 
		    128], yk2, &c__1, nr, &tmp2, &wn[1], nr);
	    tmp1 *= tmp2;
	}
	*dir += tmp1;
    }
    *dir += c2_hm__(&l4[1], &n[1], &hl0[ip[2] + (ip[4] << 6)], &hl0[ip[1] + (
	    ip[3] << 6)], &c__1, nel);

/*     Exchange  3<-->4 */
    *exc = (float)0.;
/* Computing MAX */
    i__4 = (i__7 = l4[1] - l4[4], abs(i__7)), i__5 = (i__1 = l4[2] - l4[3], 
	    abs(i__1));
/* Computing MIN */
    i__8 = (i__2 = l4[1] + l4[4], abs(i__2)), i__9 = (i__3 = l4[2] + l4[3], 
	    abs(i__3)), i__8 = min(i__8,i__9);
    i__6 = min(i__8,0);
    for (kk = max(i__4,i__5); kk <= i__6; kk += 2) {
	i__7 = l4[3] + l4[4] - *ll;
	tmp1 = sc_k__(&l4[1], &l4[2], &l4[4], &l4[3], &kk, ll, clkl, eps) * 
		pow_ri(&c_b27, &i__7);
	if (abs(tmp1) > *eps) {
	    i1 = ip[2];
	    i2 = ip[3];
	    yk_hm__(&i1, &i2, &pp[i1 * 701 + 1], &pp[i2 * 701 + 1], &l4[2], &
		    l4[3], &kk, nr, &rn[1], h__, zatom, yk2);
	    int3_8__(&pp[ip[1] * 701 + 1], &ipp[ip[1] + 64], &ipp[ip[1] + 128]
		    , &pp[ip[4] * 701 + 1], &ipp[ip[4] + 64], &ipp[ip[4] + 
		    128], yk2, &c__1, nr, &tmp2, &wn[1], nr);
	    tmp1 *= tmp2;
	}
	*exc += tmp1;
    }
    *exc += c2_hm__(&l4[1], &n[1], &hl0[ip[2] + (ip[3] << 6)], &hl0[ip[1] + (
	    ip[4] << 6)], &c__0, nel);

    return 0;
} /* d_e_hm_v4_1__ */

#ifdef __cplusplus
	}
#endif
