From 
Poet 1978 JPhysB 17, 3081
Poet 1980 JPhysB 19, 2995

2s1_3.txt   x[k^2],   y[pi*a_0^2]
??? 2s08_1.txt  x[?] or *0.0125 [Ry],    y[?]  *0.029412 => [pi*a_0^2]
