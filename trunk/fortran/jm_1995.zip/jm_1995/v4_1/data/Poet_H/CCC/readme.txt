Date: Mon, 21 Mar 94 09:58:12 CST
From: igor (Dr. Igor Bray)
Message-Id: <9403210028.AA11149@esm.ph.flinders.edu.au>
To: dima
Subject: S=0: 1s,2s,3s,TICS,TCS,S=1: 1s,2s,3s,TICS,TCS (pi a0**2)
Status: R

